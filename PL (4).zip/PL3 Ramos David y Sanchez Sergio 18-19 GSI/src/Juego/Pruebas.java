/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Juego;

import ClasesPersonajes.FrutaEstrella;
import ClasesPersonajes.Petacereza;

/**
 *
 * @author david
 */
public class Pruebas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        FrutaEstrella fe = new FrutaEstrella();
        System.out.println(fe.getDaño());
        System.out.println(fe.getFrecuencia());
        
    }
    
}
